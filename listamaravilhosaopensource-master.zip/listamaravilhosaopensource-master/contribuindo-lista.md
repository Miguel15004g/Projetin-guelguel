# Quero contribuir com a Lista Maravilhosa

1. Faça Fork do projeto
2. Crie uma nova branch: `git checkout -b nova-branch`
3. Commit suas mudanças: `git commit -m 'Adicionei alguma coisa'`
4. Push para a branch: `git push origin nova-branch`
5. Abra um Pull Request

## PR is Merged

Depois que o seu PR for unido ao projeto, você pode deletar a sua branch.

## Maneiras de colaborar

* Você pode criar novas issues para debatermos ideias e melhorias do projeto,
* Você pode [Adicionar um Projeto](meu-projeto.md) a lista,
* Você pode criar issue também para consertar alguma coisa ou até mesmo um PR com a correção,
* E qualquer outra coisa que você consiga pensar pra melhorar a Lista Maravilhosa (:

### [<-- Voltar para página principal](README.md)
